package com.sabanciuniv.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrialApplicationTests {

	@Test
	void contextLoads() {
	}

}
