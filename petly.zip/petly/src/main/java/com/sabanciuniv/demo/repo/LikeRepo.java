package com.sabanciuniv.demo.repo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.sabanciuniv.demo.model.Like;
import com.sabanciuniv.demo.model.User;
import com.sabanciuniv.demo.repo.UserRepo;


@Repository
public interface LikeRepo extends MongoRepository<Like, String> {	

	
}