package com.sabanciuniv.demo.model;

public class RequestBodyUserImage {
	private String imageURL;
	private String petname;
	public String getPetname() {
		return petname;
	}
	public void setPetname(String petname) {
		this.petname = petname;
	}
	public String getImageURL() {
		return imageURL;
	}
	public void setImageURL(String imageURL) {
		this.imageURL = imageURL;
	}
}
