package com.sabanciuniv.demo.service;

import java.util.List;
import java.util.Optional;
import java.time.LocalDateTime;

import org.bson.types.ObjectId;
import org.springframework.stereotype.Service;

import com.sabanciuniv.demo.model.Pet;
import com.sabanciuniv.demo.model.RequestBodyUserPet;
import com.sabanciuniv.demo.model.Token;
import com.sabanciuniv.demo.model.User;
import com.sabanciuniv.demo.repo.PetRepo;
import com.sabanciuniv.demo.repo.UserRepo;


@Service
public class UserService {
	private final UserRepo userRepository;
	private final PetRepo petRepository;
    public UserService(UserRepo userRepository, PetRepo petRepository) {
		this.userRepository = userRepository;
		this.petRepository = petRepository;

	}
    
    // Delete a user by ID
    public void deleteUser(String userId) {
    	userRepository.deleteById(userId);
    }  

    public User loginUser(User user) throws Exception{
		User userExists = userRepository.findByUsernameAndPassword(user.getUsername(), user.getPassword());
		System.out.println(user.getPassword());
		if(userExists==null) {
			throw new Exception("Entered information is wrong.");
		}else {
			String tokenText = new ObjectId().toString();
			Token token = new Token(tokenText,LocalDateTime.now().plusDays(100));
			userExists.setToken(token);
			userExists = userRepository.save(userExists);
			return userExists;
		}
	}
    public User registerUser(User user) {
        if (userRepository.existsByUsername(user.getUsername())) {
            throw new RuntimeException("Username already exists");
        }

        try {
            return userRepository.save(user);
        } catch (Exception e) {
            throw new RuntimeException("Unable to register user: " + e.getMessage());
        }
    }
    
    public User getUserByToken(String tokenStr) {
		User userExists = userRepository.findByTokenString(tokenStr);
		return userExists;
		
	}
	
	public void destroyToken(String tokenStr) {
		User userExists = userRepository.findByTokenString(tokenStr);
		
		userExists.setToken(null);
		
		userRepository.save(userExists);
		
	}
	
	public User getCurrentUser(String userID) {
    	return userRepository.findById(userID)
    	        .orElseThrow(() -> new RuntimeException("Unable to find the user with ID: " + userID));
    }
    
    public void savePetToUser(RequestBodyUserPet object){
		Pet petexists = petRepository.findByname(object.getPetname());//.orElseThrow(()-> new RuntimeException("Unable to find the pet with ID: " + petID));
    	User userexists = userRepository.findByUsername(object.getUsername()); //.orElseThrow(()-> new RuntimeException("Unable to find the user with ID: " + userID));


    	if( userexists == null) {
    		
    		throw new RuntimeException("Wrong user.");
    	}
    	if(petexists==null ) {
    		throw new RuntimeException("Wrong petn.");

    	}
    	else {
    		String tokenText = new ObjectId().toString();
			Token token = new Token(tokenText,LocalDateTime.now().plusDays(100));
			userexists.setToken(token);
    		userexists.setPetId(petexists.getId()); 
    		userRepository.save(userexists);
    	}
    }
    
    public void countLike(RequestBodyUserPet object) {
    	Pet pet = petRepository.findByname(object.getPetname());
        List<String> theLikeList = pet.getLike().getLikes();
        User currentUser = userRepository.findByUsername(object.getUsername());
        if(currentUser.getPetId().equals(pet.getId())) {
        	 currentUser.setLikeCount(theLikeList.size());
             petRepository.save(pet);
             userRepository.save(currentUser);
        }
        else {
        	throw new RuntimeException("This pet belongs to another user.");        
        	
        }
       
    }
}

