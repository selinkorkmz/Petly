package com.sabanciuniv.demo.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.time.LocalDateTime;

import com.sabanciuniv.demo.model.*;
import com.sabanciuniv.demo.repo.UserRepo;
import com.sabanciuniv.demo.service.UserService;


@RestController
@RequestMapping("/petly/user") 
public class UserController {

	@Autowired private UserService userService;
	@Autowired private UserRepo userRepo;

	Logger logger = LoggerFactory.getLogger(UserController.class);
	
	@PostMapping("/auth/login")
	public Payload<Token> loginUser(@RequestBody User user){
		
		try {
			user = userService.loginUser(user);
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
		
		return new Payload<Token>(LocalDateTime.now(),"OK",user.getToken());
	}
	
	@GetMapping("/auth/logout")
	public Payload<String> logoutUser(@RequestHeader String token){

		userService.destroyToken(token);
		return new Payload<String>(LocalDateTime.now(),"OK","Token destroyed.");
		
	}
	
	@PostMapping("/auth/register")
	public Payload<String> registerUser(@RequestBody User user) throws UserException{
		
		if(user.getUsername()==null ||  
				user.getPassword()==null || 
				user.getEmail() ==null||
				user.getPhoneNumber() == null) {
			logger.error("User field problem");
			throw new UserException("All fields are required.");
		}
		
		try {
			userService.registerUser(user);
		} catch (Exception e) {
			logger.error(e.getMessage());

			throw new UserException(e.getMessage());
		}
		userRepo.save(user);
		
		return new Payload<String>(LocalDateTime.now(),"OK", "User registered.");
	}
	
	@PostMapping("/savepettouser")
	public Payload<Token> savePetToUser(@RequestBody RequestBodyUserPet object){
		//System.out.println(object.getPet().getName());
		
		
		try {
			userService.savePetToUser(object);
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
		return new Payload<Token>(LocalDateTime.now(),"Pet connected to its owner.", userRepo.findByUsername(object.getUsername()).getToken());
	}
	
	@GetMapping("/countlike")
	public Payload<String> countLike(@RequestBody RequestBodyUserPet object) throws UserException{
		try {
			userService.countLike(object);
		} catch (Exception e) {
			logger.error(e.getMessage());
		
			throw new UserException(e.getMessage());
		}
		return new Payload<String>(LocalDateTime.now(),"OK", "Likes of the pet are gained.");
	}
	
}