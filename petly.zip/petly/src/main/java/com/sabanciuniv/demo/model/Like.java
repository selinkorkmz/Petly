package com.sabanciuniv.demo.model;
import java.util.ArrayList;
import java.util.List;
public class Like {
    
	private List<String> likes = new ArrayList<>();
	private List<String> likedones = new ArrayList<>();

	
	public Like( List<String> likes, List<String> likedones) {
		super();
		this.likes = likes;
		this.likedones = likedones;
	}

	public List<String> getLikes() {
		return likes;
	}

	public void setLikes(List<String> likes) {
		this.likes = likes;
	}

	public List<String> getLikedones() {
		return likedones;
	}

	public void setLikedones(List<String> likedones) {
		this.likedones = likedones;
	}
}