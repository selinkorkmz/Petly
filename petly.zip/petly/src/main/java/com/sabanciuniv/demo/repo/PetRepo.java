package com.sabanciuniv.demo.repo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.sabanciuniv.demo.model.Pet;
import com.sabanciuniv.demo.model.User;


public interface PetRepo extends MongoRepository<Pet, String> {
	boolean existsByname(String name);
    Pet findByname(String name);
	@Override
	default void delete(Pet entity) {
		// TODO Auto-generated method stub
		
	}
	
    
}

