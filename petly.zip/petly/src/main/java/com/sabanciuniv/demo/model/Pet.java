package com.sabanciuniv.demo.model;

import java.util.ArrayList;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Pet {
	
	@Id
	private String _id;
	
    
    private String name;
    private String type; // e.g., Dog, Cat
    private String breed;
    private String age;
    private Like like;
   

	private String gender;
    private String description; // Additional details about the pet
    private String meettype;
    private List<String> Hobby;
    private List<String> imageUrls;  // List to hold image URLs
	private List<String> matches;
	

    // Constructor    
    public Pet(List<String> matches,List<String> imageUrl,User user, String name, String type, String breed, String age, String gender, String description,String meettype,List<String> Hobby) {
        
        this.name = name;
        this.type = type;
        this.breed = breed;
        this.age = age;
        this.gender = gender;
        this.description = description;
        this.meettype=meettype;
        this.imageUrls = new ArrayList<>(); 
        this.Hobby= new ArrayList<>();
        this.matches= new ArrayList<>();

    }

    public Like getLike() {
		return like;
	}

	public void setLike(Like like) {
		this.like = like;
	}

	public Pet() {
		// TODO Auto-generated constructor stub
	}

	// Getters and Setters


	public String getId() {
		return this._id;
	}
   
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getBreed() {
        return breed;
    }

    public void setBreed(String breed) {
        this.breed = breed;
    }
    
    

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    

	public String getMeettype() {
		return meettype;
	}

	public void setMeettype(String meettype) {
		this.meettype = meettype;
	}

	public List<String> getMatches() {
		return matches;
	}

	public void setMatches(List<String> matches) {
		this.matches = matches;
	}
	
	public List<String> getHobby() {
	    	return Hobby;
	    }
	 
	public void setHobby(List<String> Hobby) {
    	
		this.Hobby = Hobby;
    }
	public List<String> getImageUrls() {
        return imageUrls;
    }
    
    public void setImageUrls(List<String> imageUrls) {
        this.imageUrls = imageUrls;
    }
}