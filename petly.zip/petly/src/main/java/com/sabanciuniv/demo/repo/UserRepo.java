package com.sabanciuniv.demo.repo;


import java.util.List;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.sabanciuniv.demo.model.User;


@Repository
public interface UserRepo extends MongoRepository<User, String> {
	
    User findByUsername(String username);
    //boolean existsByUserId(String _id);
    boolean existsByUsername(String username);
    
    
    
	
	User findByUsernameAndPassword(String username, String password);
    @Query("{'token.token':?0}")
    public User findByTokenString(String tokenstr);
    // Additional custom queries as needed
}