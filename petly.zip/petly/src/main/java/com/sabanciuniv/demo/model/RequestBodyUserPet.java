package com.sabanciuniv.demo.model;

public class RequestBodyUserPet {
private String username;
private String petname;




public RequestBodyUserPet(String username, String petname) {
	super();
	this.username = username;
	this.petname = petname;
}
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public String getPetname() {
	return petname;
}
public void setPetname(String petname) {
	this.petname = petname;
}

}
