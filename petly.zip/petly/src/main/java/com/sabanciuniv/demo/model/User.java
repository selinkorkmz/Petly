package com.sabanciuniv.demo.model;

import org.springframework.data.annotation.Id;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class User {
		/*
		@Id
	    private String userId;
		@Indexed(unique = true)
		*/
	
		@Id
		private String _id;
		
		
		private String petId;
		
	    private String username;
	    private String email;
		private Token token;
	    private String password;
		private int likeCount;
	    private Long phoneNumber;

	    // Constructor
	    public User(String _id, String username, String email, String password, int likeCount, Token token) {
	        this._id = _id;
	        this.username = username;
			this.likeCount = likeCount;
	        this.email = email;
	        this.password = password;
	        this.token = token;
	    }
	    
	    
	    public String getPetId() {
			return petId;
		}


		public void setPetId(String petId) {
			this.petId = petId;
		}


		public User() {
	        
	    }
	    
	    // Getters and Setters

		public String getId() {
	        return _id;
	    }

	    public Token getToken() {
			return token;
		}

		public void setToken(Token token) {
			this.token = token;
		}

		public Long getPhoneNumber() {
			return phoneNumber;
		}

		public void setPhoneNumber(Long phoneNumber) {
			this.phoneNumber = phoneNumber;
		}

	    
	    public int getLikeCount() {
			return likeCount;
		}

		public void setLikeCount(int likeCount) {
			this.likeCount = likeCount;
		}
	    
	    public String getUsername() {
	        return username;
	    }

	    public void setUsername(String username) {
	        this.username = username;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }

	    public String getPassword() {
	        return password;
	    }
	    
	    public void setPhone(Long phoneNumber) {
	    	this.phoneNumber = phoneNumber;
	    }
	    
	    public Long getPhone() {
	    	return phoneNumber;
	    }

	    public void setPassword(String password) {
	        this.password = password;
	    }

	  

		public User orElseThrow(Object object) {
			// TODO Auto-generated method stub
			return null;
		}
	}