package com.sabanciuniv.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.sabanciuniv.demo.model.*;
import com.sabanciuniv.demo.service.*;

@RestController
@RequestMapping("/petly/pets")
public class PetController {

	@Autowired private PetService petService;
	

	
	@PostMapping("/createpet")
	public Payload<String> createPet(@RequestBody Pet pet)throws UserException{
		
		if (pet.getName() == null) {
	        throw new UserException("Name is required.");
	    }
	    if (pet.getType() == null) {
	        throw new UserException("Type is required.");
	    }
	    if (pet.getBreed() == null) {
	        throw new UserException("Breed is required.");
	    }
	    if (pet.getAge() == null) {
	        throw new UserException("Age is required.");
	    }
	    if (pet.getGender() == null) {
	        throw new UserException("Gender is required.");
	    }
	    if (pet.getDescription() == null) {
	        throw new UserException("Description is required.");
	    }
	    if (pet.getMeettype() == null) {
	        throw new UserException("Meet type is required.");
	    }
	    if (pet.getImageUrls() == null || pet.getImageUrls().isEmpty()) {
	        throw new UserException("At least one image URL is required.");
	    }
	    
	    if (pet.getLike() == null) {
	    	
	    	List<String> d1 = new ArrayList<>();
	    	List<String> d2 = new ArrayList<>();
	    	Like dum = new Like(d1, d2);
	    	pet.setLike(dum);
	    }
	    if (pet.getMatches() == null) {
	    	
	    	List<String> newmathces = new ArrayList<>();
	    	pet.setMatches(newmathces);
	    }
		
		try {
			petService.createPet(pet);
			
		} catch (Exception e) {
			
			throw new UserException(e.getMessage());
		}
		return new Payload<String>(LocalDateTime.now(),"OK", "Pet created.");
	}
	
	@PostMapping("/createimage")
	public Payload<String> addImages(@RequestBody RequestBodyUserImage object){
		
		try {
			petService.addImageUrl(object);
			System.out.println(object);
		} catch (Exception e) {
			
			throw new UserException("Unable to upload the images" + e.getMessage());
		}
		return new Payload<String>(LocalDateTime.now(),"OK", "Image is uploaded.");
	}
}
