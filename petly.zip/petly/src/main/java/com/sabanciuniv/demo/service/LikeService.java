package com.sabanciuniv.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sabanciuniv.demo.controller.UserException;
import com.sabanciuniv.demo.model.*;
import com.sabanciuniv.demo.repo.PetRepo;
import com.sabanciuniv.demo.repo.UserRepo;



@Service
public class LikeService {

	@Autowired
    private UserRepo userRepo;
    @Autowired
    private PetRepo petRepo; // Assuming you have a Pet repository

    // Method to handle adding a pet to likes and updating both liker and liked lists
    public void addPetToLikesAndUpdateBoth(RequestBodyUsers Object) {
    	User userLiker = userRepo.findByUsername(Object.getUsername1());
		Optional<Pet> liker = petRepo.findById(userLiker.getPetId());
		// liker 1. paramterenin
		// liked 2.parametrenin
    	User userLiked = userRepo.findByUsername(Object.getUsername2());
		Optional<Pet> liked = petRepo.findById(userLiked.getPetId());
	    	try {
	    		
				// Add the liked pet to the liker's likes list if not already present
	    		if(liked.get().getMeettype().equals(liker.get().getMeettype())) {

	    			if (!(liker.get().getLike().getLikedones().contains(liked.get().getId()))) {

		                liker.get().getLike().getLikedones().add(liked.get().getId());
		                petRepo.save(liked.get());
 
		            }
	    			else {
		    			throw new UserException("Error occured within likelists, state 1.");
		    		}
	    			
	    			
	    		}
	    		else {
	    			throw new UserException("Meettypes do not match");
	    		}
			} catch (Exception e) {
				throw new UserException(e.getMessage());
			}

	    	try {
	    		// Add the liker pet to the liked's likedones list if not already present
	    		if(liked.get().getMeettype().equals(liker.get().getMeettype())) {
		            if (!(liked.get().getLike().getLikes().contains(liker.get().getId()))) {
		                liked.get().getLike().getLikes().add(liker.get().getId());
		                petRepo.save(liked.get());
		            }
		            else {
		    			throw new UserException(liked.get().getName()+" " + liked.get().getLike().getLikedones().contains(liker.get().getId()) +" Error accesing likelists, state 1.");
		    		}
		            
	    		}
	    		else {
	    			throw new UserException("Meettypes do not match");
	    		}
			} catch (Exception e) {
				throw new UserException(e.getMessage());
			}

            // Check if there's a mutual like and handle accordingly
	    	petRepo.save(liker.get());
            petRepo.save(liked.get());
            checkAndHandleMutualLikes(liker, liked);
    }

    // Method to check and handle mutual likes
    private void checkAndHandleMutualLikes(Optional<Pet> liker, Optional<Pet> liked) {
        if (liker.get().getLike().getLikedones().contains(liked.get().getId()) && liked.get().getLike().getLikes().contains(liker.get().getId())) {
            // Ensure they are in each other's match list
        	System.out.println(liker.get().getMatches());
            if (!liker.get().getMatches().contains(liked.get().getId())) {
                liker.get().getMatches().add(liked.get().getId());
            }
            else {
    			throw new UserException("Liker already has this match?");
    		}
        	System.out.println(liked.get().getMatches());

            if (!liked.get().getMatches().contains(liker.get().getId())) {
                liked.get().getMatches().add(liker.get().getId());
            }else {
            	throw new UserException("Liked already has this match?");
            }
            petRepo.save(liker.get());
            petRepo.save(liked.get());
        }
        else {
			throw new UserException("Error encountered adding the likes to pets.");
		}
    }
    
   public List<User> listPossibleMeets(String username) {
	    List<User> userlist = userRepo.findAll();

        String meetType = petRepo.findById(userRepo.findByUsername(username).getPetId()).get().getMeettype();
        List<User> finalList = new ArrayList<>();
        for(int x=0; x < userlist.size(); x++) {
        	if(petRepo.findById(userlist.get(x).getPetId()).get().getMeettype().equals(meetType) && userlist.get(x)!= userRepo.findByUsername(username)) {
        		try {
        			finalList.add(userlist.get(x));
        		}
        		catch(Exception e) {
        			throw new UserException(e.getMessage());
        		}
        		
        	}
        }

        return finalList;
    }
   
}