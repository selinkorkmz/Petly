package com.sabanciuniv.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sabanciuniv.demo.model.*;
import com.sabanciuniv.demo.repo.*;

@Service
public class PetService {
	@Autowired
	private PetRepo petRepo;

	public PetService(PetRepo PetRepo) {
		this.petRepo = PetRepo;

	}

	public Pet createPet(Pet pet) {

		if (petRepo.existsByname(pet.getName())) {
			throw new RuntimeException("Pet name already exists");
		} else {
			try {
				return petRepo.save(pet);
			} catch (Exception e) {
				throw new RuntimeException("Unable to create the pet: " + e.getMessage());
			}
		}

	}

	public void addImageUrl(RequestBodyUserImage object) {
		if (petRepo.findByname(object.getPetname()) != null) {
			if (object.getImageURL() != null && !object.getImageURL().trim().isEmpty()) {

				Pet p = petRepo.findByname(object.getPetname());
				List<String> exsitingImgUrls = p.getImageUrls();

				exsitingImgUrls.add(object.getImageURL());
				p.setImageUrls(exsitingImgUrls);
				
				System.out.println(p.getId());
				System.out.println(p.getName());
				System.out.println(p.getImageUrls());
				
				petRepo.save(p);				
				
			} else {
				throw new RuntimeException("Valid URL not provided.");
			}
		} else {
			throw new RuntimeException("Such pet does not exist.");
		}
	}

	// Delete a Pet
	public void deletePet(String name) {
		petRepo.delete(petRepo.findByname(name));
	}

	// Find pet by ID in a list of pets
	public Pet findByPetIdIn(List<Pet> pets) {
		// Assuming petRepo.findByPetIdIn would return the first match found
		for (Pet pet : pets) {
			if (petRepo.existsById(pet.getId().toString())) {
				return pet;
			}
		}
		return null;
	}

}