package com.sabanciuniv.demo.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.time.LocalDateTime;
import java.util.List;

import com.sabanciuniv.demo.model.*;
import com.sabanciuniv.demo.repo.*;
import com.sabanciuniv.demo.service.*;



@RestController
@RequestMapping("/petly/user")
public class LikeController {
	
	@Autowired PetRepo petRepo;
	@Autowired UserRepo userRepo;
	@Autowired LikeService likeService;
	@Autowired UserService userService;


	@PostMapping("/checkmatches")
	public Payload<String> checkMatches(@RequestBody RequestBodyUsers Object){
		
		try {
			likeService.addPetToLikesAndUpdateBoth(Object);
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
		
		return new Payload<String>(LocalDateTime.now(), "OK", "Necessary matches are made.");		
	}
	@GetMapping("/displaymatches")
	public Payload<List<String>> displayMatches(@RequestBody RequestBodyUserPet Object){
		
		User user = userRepo.findByUsername(Object.getUsername());
		
		try {
			System.out.println(petRepo.findById(user.getPetId()).get().getMatches());
			petRepo.findById(user.getPetId()).get().getMatches();
		} catch (Exception e) {
			throw new UserException(e.getMessage());
		}
		
		return new Payload<List<String>>(LocalDateTime.now(), "OK", petRepo.findById(user.getPetId()).get().getMatches());		
	}
	@GetMapping("/viewpossiblematches")
	public Payload<List<User>> listPossibleMeets(@RequestBody RequestBodyUserPet Object){
		
		User user = userRepo.findByUsername(Object.getUsername());
		
		try {
			likeService.listPossibleMeets(user.getUsername());
		} catch (Exception k) {
			System.out.println("aaaaa");
			throw new UserException(k.getMessage());
		}
		
		return new Payload<List<User>>(LocalDateTime.now(), "OK", likeService.listPossibleMeets(user.getUsername()));		
	}
}
